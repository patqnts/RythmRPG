﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Unity.PixelGraphics.Editor")]