## [1.0.1](https://github.com/aarthificial/pixelgraphics/compare/v1.0.0...v1.0.1) (2021-06-20)

### Installation url
```
https://github.com/aarthificial/pixelgraphics#v1.0.1
```


### Bug Fixes

* fix normal shaders ([488c0c7](https://github.com/aarthificial/pixelgraphics/commit/488c0c70b04d203b601d250c1d5d408cdc132737))

# 1.0.0 (2021-06-20)

### Installation url
```
https://github.com/aarthificial/pixelgraphics#v1.0.0
```


### Bug Fixes

* fix emitter layer detection ([9a786b7](https://github.com/aarthificial/pixelgraphics/commit/9a786b7a5bb1e0f11c7b9e1f63709d5a9d3d151e))
